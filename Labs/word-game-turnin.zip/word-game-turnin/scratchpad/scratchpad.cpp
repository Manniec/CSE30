#include <iostream>
#include <myLib.h>


int main(){
	/*
	std::string test = "ABCDEFGHI";
	std::vector<std::string> ps = powerset(test); //all possible substrings of test
	std::vector<std::string> result;

    std::cout << "Substring Permutations ";
    for (std::string item : ps){ //for each substring of test
        if(item.size() > 0){ //if substring isnt empty string 
			std::vector<std::string> curr; //curr == array of strings
			permute(item, 0, item.size()-1, curr); //permute each substring 

			for (int i = 0; i < curr.size(); i++){ 
				result.push_back(curr[i]); // for each substring append each permutation to result
			}
		} 
    } 

	std::cout << "(" << result.size() << ")" << std::endl << std::endl;

	std::cout << getList() << std::endl;

	// for (int i = 0; i < result.size(); i++){
	// 	std::cout << result[i] << std::endl;
	// }
	*/
	
	return 0;
}
