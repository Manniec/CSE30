int add (int, int);
int times (int, int);
